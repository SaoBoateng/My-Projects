/*
 * Budget.java file submission
 */
  public class Budget {
 public static void main (String[] args ) {
     System.out.println();
     System.out.println("Welcome To Smart Barracuda Tutoring Services");
    System.out.println();
    double hourlyWage1 = 10*.9;
    
     int apartmentRent = 1099;

    int phoneBill = 55; 

    int carNote = 515;
    
    int carInsurance = 151;
    
    int rentersInsurance = 17;

    int utilityBill = 144;

    int wifiBill = 64;

    int gasBill = 50;

    int appleMusic = 5;
    
    int groceryList = 360;

    int funMoney = 100;

    double monthlyExpense = (hourlyWage1 + apartmentRent+ phoneBill + carNote + carInsurance + wifiBill + gasBill + appleMusic + groceryList+ funMoney);

    double hoursNeeded = ((double) monthlyExpense/hourlyWage1);

    double hoursSave = ((double) (monthlyExpense+100)/hourlyWage1);

    double hoursEven = (hoursNeeded/4);

    System.out.println(" Hourly wage: " + hourlyWage1) ;
    System.out.println();
        //prints out hourly wage
     System.out.println("Rent: " + apartmentRent);
     System.out.println();
        //prints out rent
     System.out.println("Phone bill: " + phoneBill);
     System.out.println();
        //prints out phone bill
    System.out.println("Car note: "+ carNote);
    System.out.println();
        //prints out car note
     System.out.println("Car insurance: "+ carInsurance);
     System.out.println();
        //prints car insurance
     System.out.println("Renters Insurance: "+rentersInsurance);
     System.out.println();
        // prints out renters insurance
     System.out.println("Utilities: " + utilityBill);
     System.out.println();
        // prints out utility bill
     System.out.println("Wifi: " + wifiBill);
     System.out.println();
        // prints out wifi bill
     System.out.println("Groceries: " + groceryList);
     System.out.println();
        //prints out grocery list    
     System.out.println("Apple Music Subscription: "+ appleMusic);
     System.out.println();
        //prints out apple music subscription
     System.out.println("Gas: "+ gasBill);
     System.out.println();
        //prints out the gas bill
        System.out.println("Leisure Money: " + funMoney);
        System.out.println();
        //prints out the amount for leisure activities
    System.out.println("Total Monthly Expenses: "+ monthlyExpense);
    System.out.println();
        // prints out the total monthly expenses
    System.out.println("Hours needed to afford monthly expenses: " + hoursNeeded);
    System.out.println();
        // prints out hours needed to afford monthly expenses
    System.out.println("Hours needed to save $100 per month: "+ hoursSave);
    System.out.println();
        // prints out hours needed to save $100 per month
    System.out.println("Hours needed to break even per week: "+ hoursEven);
    System.out.println();
        // prints hours needed to break even and spend the amount earned
        System.out.println("I need to work more hours or get a better paying job!!");
    }//end main
}//end class 