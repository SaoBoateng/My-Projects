public class CD 
{
    private String title;
    private double price;
    private int stock;
    
    
    public CD(String title_,double price_, int stock_)
    {
        title = title_;
        price = price_;
        stock = stock_;
    }
    
 public int getStock()        
{
return stock;
}

public void setStock( int stock)
{
this.stock = stock;
}

public String getTitle()
{
    return title;
}

public void setTitle(String title)
{
    this.title = title;
}

public double getPrice() 
{
    return price ;
}

public void set(double price)
{
    this.price=price;
}
    }
    
    
    
//}
