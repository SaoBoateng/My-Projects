public class DVD 
{
    private String title;
    private double price;
    private int releaseYear;
    
     public DVD (String title_,double price_, int releaseYear_)
    {
        title = title_;
        price = price_;
        releaseYear = releaseYear_;
    }
    
    public int getReleaseYear() 
{
return releaseYear;
}

public void setReleaseYear( int releaseYear)
{
this.releaseYear = releaseYear;
}

public String getTitle()
{
    return title;
}

public void setTitle(String title)
{
    this.title = title;
}

public double getPrice() 
{
    return price ;
}

public void set(double price)
{
    this.price=price;
}
    }
    

