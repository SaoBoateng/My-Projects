import java.util.ArrayList;
import java.util.List;

public class Inventory {
    private ArrayList<CD> cds;
    private ArrayList<DVD> dvds;
    private ArrayList<Book> books;
    private ArrayList<Membership> memberships;

    public Inventory() {
        cds = new ArrayList<>();
        dvds = new ArrayList<>();
        books = new ArrayList<>();
        memberships = new ArrayList<>();
    }

    public void addCD(CD cd) {
        cds.add(cd);
    }

    public ArrayList<CD> getCds() {
        return cds;
    }

   

    public ArrayList<DVD> getDvds() {
        return dvds;
    }



    public ArrayList<Book> getBooks() {
        return books;
    }

   
    public void addDVD(DVD dvd) {
        dvds.add(dvd);
    }

    public void addBook(Book book) {
        books.add(book);
    }
    
    public void addMember( Membership member)
    {
        memberships.add(member);
    }

    public ArrayList<Membership> getMemberships() {
        return memberships;
    }

    //}

    // Method to display the inventory
    public void displayInventory() {
        System.out.println("Inventory:");
        System.out.println("Book:");
        for (Book book : books) {
            System.out.println("- " + book.getTitleName() + ", it costs " + book.getPrice() + ", " + " (" + book.getYearPublished() + ")");
        }
        System.out.println("CD:");
        for (CD cd : cds) {
            System.out.println("- " + cd.getTitle() + ", it costs " + cd.getPrice() + ", " + " (" + cd.getStock() + " in stock)");
        }
        System.out.println("DVD:");
        for (DVD dvd : dvds) {
            System.out.println( "- " + dvd.getTitle()+ ", Which came out: "+ dvd.getReleaseYear() + ", and costs " + dvd.getPrice() + " dollars");
        }
    }
}


