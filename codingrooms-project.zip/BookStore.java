import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * 
 */
public class BookStore {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
     ArrayList<DVD> inventory = new ArrayList();
     ArrayList<CD> inventory1 = new ArrayList();
     ArrayList<Book> inventory2 = new ArrayList();
     ArrayList <Membership> inventory3 = new ArrayList();
    Scanner input = new Scanner(System.in);
        
    Inventory myInventory = new Inventory();
    
    Membership myMembership = new Membership("Roger",false,"Card",false);
    myInventory.addMember(myMembership);
    
    Membership myMembership2 = new Membership("Billy",false,"Card",false);
    myInventory.addMember(myMembership2);
    
    Membership myMembership3 = new Membership("Bobby",false,"Card",false);
    myInventory.addMember(myMembership3);
    
     Membership currentMember = new Membership();
    
    
        // Create inventory
        myInventory.addBook(new Book("The Great Gatsby",1925 , 1234 ,14.99));
        myInventory.addBook(new Book("To Kill a Mockingbird",1960,4567, 12.99));
        myInventory.addDVD(new DVD("The Shawshank Redemption",9.99,1994));
        myInventory.addDVD(new DVD(" The Godfather",11.99, 1972));
        myInventory.addCD(new CD("Thriller",8.99, 100));
        myInventory.addCD(new CD("Dark Side of the Moon", 10.99,345));
        
        boolean stop = false;
        
        while (stop == false)

        {
        // Display options to user
        System.out.println("Welcome to the Bookstore!");
        System.out.println("What would you like to do?");
        System.out.println("1. View cart");
        System.out.println("2. Purchase item");
        System.out.println("3. Choose member");
        System.out.println("4. Create new Member ");
        System.out.println("5. Exit ");
        int choice = input.nextInt();
        input.nextLine();
        
        // Perform action based on user's choice
        switch(choice) {
            case 1:
               System.out.println(currentMember.displayInventory());
                break;
            case 2:
                myInventory.displayInventory();
                System.out.println("What type of product are you looking for?");
                String firstQuestion = input.nextLine();
                System.out.println("And what is the name of the product are you looking for?");
                String secondQuestion = input.nextLine();
                
               if(currentMember.purchaseItem(myInventory,firstQuestion,secondQuestion)){
                   System.out.println("Purchase Successful");
                   
               }
               else
               {
                   System.out.println("Purchase unsucessful");
               }
                break;
            case 5:
                System.out.println("Goodbye!");
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please try again.");
                main(args);
                break;
            case 3:
                System.out.println("Select a member");
                for(int i=0; i<myInventory.getMemberships().size();i++)
                {
                    System.out.println(i+") "+myInventory.getMemberships().get(i).getMemberName());  
                  
                }
                int decision = input.nextInt();
                
                input.nextLine();
                
       
                if(decision==0)
                {
                    currentMember = myMembership;
                }
                else if( decision == 1)
                {
                  currentMember = myMembership2;
                }
                else if (decision ==3)
                {
                    currentMember = myMembership3;
                }
                break;
            case 4:
                 
                System.out.println("Become new Member");
                System.out.println("What is your full name?");
                String fullName = input.nextLine();
                
                System.out.println("Do you want to be a premimum member? (true/false)");
                 boolean premiumMember =input.nextBoolean();
                 
                System.out.println("What is your method of payment?");
                String paymentMethod = input.nextLine();
                
                System.out.println("Congratulations, you are now a member!");
                
                Membership newMember =  new Membership(fullName,false,paymentMethod,premiumMember);
                
                myInventory.addMember(newMember);
                break;
            }
        }
    }
    
    
        // TODO code application logic here
    }
    

