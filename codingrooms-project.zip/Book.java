public class Book 
        
{
    private String titleName;
    private int yearPublished;
    private int bookNumber;
    private double price;   

     public Book (String titleName_, int yearPublished_ , int bookNumber_, double price_)
    {
        titleName = titleName_;
        price = price_;
        yearPublished = yearPublished_;
        bookNumber = bookNumber_;
        
    }

public int getYearPublished() 
{
return yearPublished;
}

public void setYearPublished( int yearPublished)
{
this.yearPublished = yearPublished;
}

public int getBookNumber()
{
    return bookNumber;
}

public void set(int bookNumber)
{
    this.bookNumber = bookNumber;
}

public double getPrice() 
{
    return price ;
}

public void set(double price)
{
    this.price=price;
}

public String getTitleName() 
{
    return titleName;
}

public void setTitleName(String titleName)
{
    this.titleName=titleName;
}
    }
