import java.util.ArrayList;

public class Membership {
    private String memberName;
    private boolean monthlyFeeStatus;
    private double totalCost = 0;
    private String methodOfPayment;
    private boolean isPremium;
    
    private ArrayList<CD> cds = new ArrayList <>();
    private ArrayList<DVD> dvds = new ArrayList <>();
    private ArrayList<Book> books = new ArrayList <>();
    
    public Membership(String memberName, boolean monthlyFeeStatus,String methodOfPayment, boolean isPremimum)
    {
        this.memberName = memberName;
        this.monthlyFeeStatus = monthlyFeeStatus;
        this.methodOfPayment = methodOfPayment;
        this.isPremium = isPremium;
        
        
    }
    
   public String displayInventory()
   {
       String fullInventory = " ";
       
       for(int i=0; i<cds.size(); i++)
       {
           fullInventory+= "\n" + cds.get(i).getTitle();
       }
       for(int i=0; i<dvds.size(); i++)
       {
           fullInventory+= "\n" + dvds.get(i).getTitle();
       }
       for(int i=0; i<books.size(); i++)
       {
           fullInventory+= "\n" + books.get(i).getTitleName();
       }
       return fullInventory;
   }
            
    public Membership()
    {
        
    }
    
      public String getMemberName() 
{
return memberName;
}

public void setMemberName(String memberName)
{
this.memberName = memberName;
}

public boolean getMonthlyFeeStatus(boolean monthlyFeeStatus) 
{
    return monthlyFeeStatus ;
}

public void set(boolean monthlyFeeStatus)
{
    this.monthlyFeeStatus=monthlyFeeStatus;
}

public double totalCost()
{
    return totalCost;
}

public void setTotalCost(double totalCost)
{
    this.totalCost = totalCost;
}

public String getMethodOfPayment(String methodOfPayment) 
{
    return methodOfPayment;
}

public void setMethodOfPayment(String methodOfPayment)
{
    this.methodOfPayment=methodOfPayment;
}

 public Membership(boolean isPremium) 
 {
    this.isPremium = isPremium;
  }

  public boolean isPremium() 
  {
    return isPremium;
  }
  
  public boolean purchaseItem (Inventory displayInventory, String type, String itemName_ )
  {
      if(type.equalsIgnoreCase("CD"))
      {
          for(int i=0; i<displayInventory.getCds().size(); i++){
              if(itemName_.equalsIgnoreCase(displayInventory.getCds().get(i).getTitle()))
              {
                  totalCost+= displayInventory.getCds().get(i).getPrice();
                  
                  cds.add(displayInventory.getCds().get(i));
                  
                  displayInventory.getCds().remove(i);
                  
                  return true;
              }
          }
        
      }
       if(type.equalsIgnoreCase("Book"))
      {
          for(int i=0; i<displayInventory.getBooks().size(); i++){
              if(itemName_.equalsIgnoreCase(displayInventory.getBooks().get(i).getTitleName()))
              {
                  totalCost+= displayInventory.getBooks().get(i).getPrice();
                  
                  books.add(displayInventory.getBooks().get(i));
                  
                  displayInventory.getBooks().remove(i);
                  
                  return true;
                  
              }
          }
        
      }
        if(type.equalsIgnoreCase("DVD"))
      {
          for(int i=0; i<displayInventory.getDvds().size(); i++){
              if(itemName_.equalsIgnoreCase(displayInventory.getDvds().get(i).getTitle()))
              {
                  totalCost+= displayInventory.getDvds().get(i).getPrice();
                  
                  dvds.add(displayInventory.getDvds().get(i));
                  
                  displayInventory.getDvds().remove(i);
                  
                  return true;
                 
              }
          }
        
      }
        return false;
  }
}
  
    
    
  
