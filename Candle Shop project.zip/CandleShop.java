import java.util.Scanner;

public class CandleShop {

public static void main(String[] args)
{
/** 
 *Complete Project 3 Here
 */


    Scanner ascanner = new Scanner (System.in);

    //Greet User
    System.out.println("Welcome to the Candle Shop!");
    ascanner.nextLine();

    System.out.println();

    //Variable set for CandleOne
    Candle candleOne = new Candle ( "Wood" , 1 ,  .50 , 4 );
    //Variable set for candleTwo
    Candle candleTwo = new Candle ( "Ocean" , 2 ,  .60 , 5 );
    //Variable set for CandleThree
    Candle candleThree = new Candle ( "Lavender" , 3  , .70 , 6 );

    //Print all Candle Values
    System.out.println(candleOne.toString());

    System.out.println();

    System.out.println(candleTwo.toString());

    System.out.println();

    System.out.println(candleThree.toString());

    System.out.println();

    //Ask the user if they would like use the store values or their own
    System.out.println("Would you like to use these values, or use your own? Type \"no to create new candles\"");

    String shopOwner = ascanner.nextLine();

    //Begin if
    if (shopOwner.equalsIgnoreCase("no")) {


        //Changing Candle 1
        System.out.println(" Enter name for your first candle: ");
        String candleName = ascanner.nextLine();
        System.out.println(" Enter Cost for your first candle: ");
        double candleCost = ascanner.nextDouble();
        System.out.println("Enter burn time for your first candle: ");
        int burnTime = ascanner.nextInt();
        //Modify candles
        candleOne.setName(candleName);
        candleOne.setCost(candleCost);
        candleOne.setTime(burnTime);

        //Changing Candle 2
        System.out.println(" Enter the name for your second candle: ");
        String candleName2 = ascanner.next();
        System.out.println(" Enter the Cost for your second candle: ");
        double candleCost2 = ascanner.nextDouble();
        System.out.println("Enter the burn time for your second candle: ");
        int burnTime2 = ascanner.nextInt();
        //Modify candles
        candleTwo.setName(candleName2);
        candleTwo.setCost(candleCost2);
        candleTwo.setTime(burnTime2);

        //Changing Candle 3
        System.out.println(" Enter the name for your third candle: ");
        String candleName3 = ascanner.next();
        System.out.println(" Enter the Cost for your third candle: ");
        double candleCost3 = ascanner.nextDouble();
        System.out.println("Enter the burn time for your third candle: ");
        int burnTime3 = ascanner.nextInt();
        //Modify candles
        candleThree.setName(candleName3);
        candleThree.setCost(candleCost3);
        candleThree.setTime(burnTime3);
        } //end if

     { //Prompt the user how many of candle 2 they would like to buy
       System.out.println("Enter the number of candles of each type of candle you would like to buy");
        
        int candleAmount = ascanner.nextInt();
        ascanner.nextLine();

        //Prompt the user how many of candle 1 they would like to buy
        System.out.println("How many of candle 1 would you like?");

        int candle1Amount = ascanner.nextInt();
        ascanner.nextLine();

        //Burn Time and Cost getter for candle one
        candleOne.getTime();
        candleOne.getCost();

        double candleOnetotal = candle1Amount * candleOne.getCost();
         //End prompt for candle 1 

        //Prompt the user how many of candle 2 they would like to buy
        System.out.println("How many of candle 2 would you like?");
        int candle2Amount = ascanner.nextInt();
        ascanner.nextLine();

        //Candle 2 Getter for burn time and cost
         candleTwo.getTime();
         candleTwo.getCost();

         //Candle 2 total
         double candleTwototal = candle2Amount * candleTwo.getCost();
         //End prompt for Candle 2

        //Prompt the user how many of candle 3 they would like to buy
        System.out.println("How many of candle 3 would you like?");
        int candle3Amount = ascanner.nextInt();
        ascanner.nextLine();

        //Candle 3 Getter for burn time and cost
        candleThree.getTime();
        candleThree.getCost();

        //Calculate total of candle 3
        double candleThreetotal = candle3Amount * candleThree.getCost();
        //End Prompt for Candle 3

        //Calculate total cost of candle
        double totalCandleCost = candleOnetotal + candleTwototal + candleThreetotal;

        //Use to calculate total burn time
        int totalBurnTime = (candleOne.getTime()*candle1Amount) + (candleTwo.getTime()*candle2Amount) + (candleThree.getTime()*candle3Amount);

        double discount;

        double totalDiscountCost = totalCandleCost;

        //Calculate costPerMin
        double costPerMin  = totalCandleCost/totalBurnTime;

        System.out.println();

        //Begin else if statement for candle cost
        if ( totalCandleCost >=20 && totalCandleCost <=35)
        {
        System.out.println("5.0% Discount");
        totalDiscountCost = totalCandleCost * .95;
        discount= .95;
        }
        else if( totalCandleCost > 35 && totalCandleCost <=55)
        {
        System.out.println("7.0% Discount");
        totalDiscountCost = totalCandleCost * .93;
        discount = .93;
        }
        else if( totalCandleCost > 55 && totalCandleCost <= 100 )
        {
        System.out.println("10.0% Discount");
        totalDiscountCost = totalCandleCost * .90;
        discount = .90;
        }
        else if( totalCandleCost > 100)
        {
        System.out.println("20.0% Discount");
        totalDiscountCost = totalCandleCost * .80;
        discount = .80;
        }
        else
        {
        System.out.println("0.0% Discount");
        totalDiscountCost = totalCandleCost;
        discount = 0;
            } //end else if 

            System.out.println();

            //Begin Customer Checkout
            System.out.println("Thank you for shopping at the Candle Shop!,today you purchased: " + (candle1Amount+candle2Amount+candle3Amount) + " candles");

            System.out.println();
            ascanner.nextLine();

             //Begin Candle 1 Reciept
            System.out.println("CANDLE 1 PURCHASE DETAILS:");
            ascanner.nextLine();

            System.out.println(" Today you bought "  + candle1Amount + " "  + candleOne.toString());
            ascanner.nextLine();

            System.out.println();
            //Print out before discount price for first candle
            System.out.println(" Your before discount price for your first candle is: " + "$"+candle1Amount * candleOne.getCost());
            ascanner.nextLine();

            System.out.println();
            //Print out after discount price for first candle
            System.out.println(" Your after discount price for your first candle is: " + "$"+candle1Amount * candleOne.getCost() * discount);
            ascanner.nextLine();

            System.out.println();
            //Print out total burn time for first candle
            System.out.println(" The total burn time of your first candle is: " + candle1Amount * candleOne.getTime() + " minutes ");
            ascanner.nextLine();

            System.out.println();
            //Print out cost per minute for first candle
            System.out.println( " The cost per minute for your first candle is: " + "$"+candle1Amount * candleOne.getCost() / candleOne.getTime());
            ascanner.nextLine();

            //End Candle 1 Reciept

            System.out.println();
            ascanner.nextLine();

            //Begin Candle 2 purchase
            System.out.println("CANDLE 2 PURCHASE DETAILS:");
            ascanner.nextLine();

            System.out.println(" Today you bought "  + candle2Amount + " "  + candleTwo.toString());

            System.out.println();
            ascanner.nextLine();

            //Print out before discount price for second candle
            System.out.println(" Your before discount price for your second candle is: " + "$"+candle2Amount * candleTwo.getCost());

            System.out.println();
            ascanner.nextLine();

            //Print out after discount price for second candle
            System.out.println(" Your after discount price for your second candle is: " + "$"+candle2Amount * candleTwo.getCost() * discount);

            System.out.println();
            ascanner.nextLine();

            //Print out total burn time for second candle
            System.out.println(" The total burn time of your second candle is: " + candle2Amount * candleTwo.getTime() + " minutes ");

            System.out.println();
            ascanner.nextLine();

            //Print out cost per minute for second candle
            System.out.println( " The cost per minute for your second candle is: " + "$"+candle2Amount * candleTwo.getCost() / candleTwo.getTime());
            //End Candle 2 Reciept

            System.out.println();
            ascanner.nextLine();

            //Begin Candle 3 reciept
            System.out.println("CANDLE 3 PURCHASE DETAILS:");
            ascanner.nextLine();

            System.out.println(" Today you bought " +  candle3Amount + " "  + candleThree.toString());

            System.out.println();
            ascanner.nextLine();

            //Print before discount price for third candle
            System.out.println(" Your before discount price for your third is: " + "$"+candle3Amount * candleThree.getCost());

            System.out.println();
            ascanner.nextLine();

            //Print after discount price for third candle
            System.out.println(" Your after discount price for your third candle is: " + "$"+candle3Amount * candleThree.getCost() * discount);

            System.out.println();
            ascanner.nextLine();

            //Print total burn time for third candle
            System.out.println(" The total burn time of your third candle is: " + candle3Amount * candleThree.getTime() + " minutes ");

            System.out.println();
            ascanner.nextLine();

            //Print Cost per Minute for third candle
            System.out.println( " The cost per minute for your third candle is: " + "$"+candle3Amount * candleThree.getCost() / candleThree.getTime());

            //End Candle 3 Reciept

            System.out.println();

            System.out.println("------HISTOGRAM------");

            System.out.println();

            //Begin Histogram for Candle 1
           System.out.print(candle1Amount + " Type:" + candleOne.getType() + " " + candleOne.getName() + " candles: ");
           for (int i = 0; i< candle1Amount; i++ )
           {
               System.out.print("@");
           }
            System.out.println();
            ascanner.nextLine();
            //End Histogram for Candle 1

            //Begin Histogram for Candle 2
           System.out.print(candle2Amount + " Type:" + candleTwo.getType() + " " + candleTwo.getName() + " candles: ");
           for (int i = 0; i< candle2Amount; i++ )
            {
                System.out.print("#");
            }
           System.out.println();
           ascanner.nextLine();
           //End Histogram for Candle 2

            //Begin Histogram for Candle 3
           System.out.print(candle3Amount + " Type:" + candleThree.getType() + " " + candleThree.getName() + " candles: ");
           for (int i = 0; i< candle3Amount; i++ )
           {
               System.out.print("+");
           }
            System.out.println();
        //End Histogram for Candle 3 

            System.out.println();

        //Farewell to user
        System.out.println("Thank you for shopping with us at the Candle Shop! Have a nice day!"); 
        }
    }
}
   