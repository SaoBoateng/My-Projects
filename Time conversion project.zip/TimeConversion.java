public class TimeConversion {
    
    /**
     * Constructor
     */
    TimeConversion(){
    }
    
    /**
     * TO DO: showDecaseconds method
     * Given a number of seconds calculates 
     * and display decaseconds
    */
    public void showDecaseconds(int seconds) 
    {
        
        // add your code here
        double decaSeconds = (seconds/10);
        System.out.println(decaSeconds);
        System.out.println("Decaseconds: a decasecond is 10 seconds.");
    }
    /**
     * TO DO: showJiffies method
     * Given a number of seconds calculates 
     * and display jiffies
    */
    
    public void showJiffies(int seconds) 
    {
        
        // add your code here
        System.out.println();
        double jifFies = (seconds*100);
        // Converts seconds into jiffies
        System.out.println(jifFies);
        // Prints out the value of the variable "jifFies"
        System.out.println("Jiffies: A unit of time used in computer games, it is  10 milliseconds.");
        //Prints out the definition of Jiffies
    }
    /** 
     * TO DO: showNewYorkMinutes method
     * Given a number of seconds calculates 
     * and display New York minutes
    */
    public void showNewYorkMinutes(int seconds) 
    {
        
        // add your code here
        System.out.println();
        double newYorkMinute = (seconds*20);
        // Converts Seconds into NewYorkMinutes
        System.out.println(newYorkMinute);
        //Prints out seconds in NewYorkMinutes
        System.out.println("NewYorkMinute: The period of time between the traffic lights turning green and the cab behind you honking.It is 1/20th of a second.");
        //Prints out the definition of a NewYorkMinute
   
    }
    /**
     * TO DO: showNanoCenturies method
     * Given a number of seconds calculates 
     * and display Nanocenturies
    */ 
    public void showNanoCenturies(int seconds) 
    {
        
        // add your code here
        System.out.println();
        double nanoCentury = (seconds/3.156);
        //Converts seconds into Nanocentury
        System.out.println(nanoCentury);
        //Prints out seconds in Nanocenturies
        System.out.println("Nanocentury: A computing measurement that is 3.156 seconds.");
        //Prints out the definition of a Nanocentury
   
    }
     /**
     * TO DO: showScaramuccis method
     * Given a number of seconds calculates 
     * and display Scaramuccis
    */ 
    public void showScaramuccis(int seconds) 
    {
        
        // add your code here
        System.out.println();
        double scaraMucci = (seconds/950400.0);
        //Converts seconds to Scaramucci
        System.out.println(scaraMucci);
        // Prints out seconds in Scaramucci
        System.out.println("Scaramucci: The tenure of former White House Communications Director Anthony Scaramucci, it is 11 days.");
        //Prints out the definition of a Scaramucci
   
    }
    
}//end class