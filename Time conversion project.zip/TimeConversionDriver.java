import java.util.Scanner;
public class TimeConversionDriver 
{
    public static void main(String[] args) 
    {
        // statements for output formatting
        System.out.println("*******************************");
        System.out.println("Start - Time Conversion Program");
        System.out.println("*******************************");
    
        // variable to store user input
        int numSeconds;
        /**
         * TO DO: ask the user to enter the number of seconds to be converted 
         * and assign the value to numSeconds
         */  
        // add your code here
        
        Scanner aTime= new Scanner(System.in);
        System.out.println("Enter the number of seconds here");
        numSeconds= aTime.nextInt();
        
        
        // you do not need to add anything below this line
        // create TimeConversion object
        TimeConversion converter = new TimeConversion();
        // call method to calculate Decaseconds
        converter.showDecaseconds(numSeconds);
        // call method to calculate Jiffies
        converter.showJiffies(numSeconds);
        // call method to calculate New York minutes
        converter.showNewYorkMinutes(numSeconds);
        // call method to calculate Nano Centuries 
        converter.showNanoCenturies(numSeconds);
        // call method to calculate Scaramuccis
        converter.showScaramuccis(numSeconds);
        // statements are for output formatting
        System.out.println("*******************************");
        System.out.println("End - Time Conversion Program");
        System.out.println("*******************************");
    }//end main method
}//end class
