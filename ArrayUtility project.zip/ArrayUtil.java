/**
*ArrayUtil.java goes here
*/

//Create Class
public class ArrayUtil
{
    //Integer Array Field
    int[] intArray;

    //Default Constructor
    public ArrayUtil()
    {

    }

    //Constructor that only accepts one argument
    public ArrayUtil(int[] Random)
    {
        intArray=Random;
    }

    //Create getter
    public int[] getIntArray()
    {
        //Returns intArray
        return intArray;
    }

    //Create setter
   public void setIntArray(int[] newArray)
   {
       intArray=newArray;
   }

    //Begin minValue method
    public int minValue()
    {
        //Sets minValue to 0
        int minValue=0;

        //Begin if statement
        if(intArray.length==0)
        {

            return 0;
        }

        minValue=intArray[0];

        //Begin for nested loop
        for(int i=0;i<intArray.length;i++)

        {
            //if value is less than min value
            if(intArray[i]<minValue)

            //Set minValue to that element
            minValue=intArray[i];
        }

        //Return minimum value
        return minValue;

    }
    //End method

    //Begin maxValue method
    public int maxValue()
    {
        int maxValue=0;

        //If intArray equals 0, return 0
        if(intArray.length==0)
        {
            return 0;
        }

        maxValue=intArray[0];

        for(int i=0;i<intArray.length;i++)
        
        {
            //If maxValue is greater, set maxValue to element
            if(intArray[i]>maxValue)

            maxValue=intArray[i];
        }

        //Return maxValue
        return maxValue;
        

    }
    //End maxValue method

    //Begin countUniqueIntegers method
    public int countUniqueIntegers()
    {
        int current;
        int unique = 0;
        int repeats = 1;

        //Begin outer part of  nested for loop
        for(int i=0;i<intArray.length;i++)
        {
            //set curent equal to intArray[i]
            current =intArray[i];

            //Begin for loop
            for(int j=i+1;j<intArray.length;j++)
            {
                if (current == intArray[j])
                {
                    //adds
                    repeats++;
                }
            }
            if (repeats == 1)
            {
                //adds 
                unique++;
            }
            repeats =1;
        }
        //return unique
        return unique;

        //end
        

    }
}