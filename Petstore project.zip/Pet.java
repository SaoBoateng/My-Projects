public abstract class Pet implements Comparable<Pet> {

    //  variables to store pet information
    private String name;
    private String breed;
    private String gender;
    private int age;
    private double weight;
    private int petID;
    private double price;

    // Creates new Pet object with given information
    public Pet(String name, String breed, String gender, int age, double weight, int petID, double price) {
        this.name = name;
        this.breed = breed;
        this.gender = gender;
        this.age = age;
        this.weight = weight;
        this.petID = petID;
        this.price = price;
    }

    // Accessor method for petID instance variable
    public int getPetID() {
        return petID;
    }

    // Mutator method for petID instance variable
    public void setPetID(int petID) {
        this.petID = petID;
    }

    // Accessor method for price instance variable
    public double getPrice() {
        return price;
    }

    // Mutator method for price instance variable
    public void setPrice(double price) {
        this.price = price;
    }

    // Accessor method for name instance variable
    public String getName() {
        return name;
    }

    // Mutator method for name instance variable
    public void setName(String name) {
        this.name = name;
    }

    // Accessor method for breed instance variable
    public String getBreed() {
        return breed;
    }

    // Mutator method for breed instance variable
    public void setBreed(String breed) {
        this.breed = breed;
    }

    // Accessor method for gender instance variable
    public String getGender() {
        return gender;
    }

    // Mutator method for gender instance variable
    public void setGender(String gender) {
        this.gender = gender;
    }

    // Accessor method for age instance variable
    public int getAge() {
        return age;
    }

    // Mutator method for age instance variable
    public void setAge(int age) {
        this.age = age;
    }

    // Accessor method for weight instance variable
    public double getWeight() {
        return weight;
    }

    // Mutator method for weight instance variable
    public void setWeight(double weight) {
        this.weight = weight;
    }

    // Override the compareTo() method of the Comparable interface to compare Pet objects based on price
    @Override
    public int compareTo(Pet other) {
        // Implement comparison logic based on price or another field
        return Double.compare(this.price, other.price);
    }

}
