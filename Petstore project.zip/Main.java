import java.util.*;

public class Main {
    // Compares  prices of two pets
    public static void compareProducts(PetStore ps) {
        // Creating a Scanner object to read user input
        Scanner scnr = new Scanner(System.in);

        // Prompting the user to enter the IDs of the two pets to compare
        System.out.println("Enter the ID of the first pet:");
        int petId1 = scnr.nextInt();
        System.out.println("Enter the ID of the second pet:");
        int petId2 = scnr.nextInt();

        // Finding the pets with the specified IDs in the pet store's inventory
        Pet pet1 = ps.findPetById(petId1);
        Pet pet2 = ps.findPetById(petId2);
        // Checking if both pets were found in the inventory
        if (pet1 == null || pet2 == null) {
            System.out.println("One or both pet IDs not found in the inventory.");
        } else {
            // Comparing the prices of the two pets and displaying the result
            int comparisonResult = pet1.compareTo(pet2);

            if (comparisonResult > 0) {
                System.out.println(pet1.getName() + " is more expensive than " + pet2.getName() + ".");
            } else if (comparisonResult < 0) {
                System.out.println(pet1.getName() + " is less expensive than " + pet2.getName() + ".");
            } else {
                System.out.println(pet1.getName() + " and " + pet2.getName() + " have the same price.");
            }
        }
    }
    
    //  Displays total value of the pet store's inventory
    public static void displayInventoryTotal(PetStore ps) {
        System.out.printf("The total inventory value is: $%.2f%n", ps.inventoryValue());
    }

    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        // Creates new PetStore object and displays a welcome message
        PetStore ps = new PetStore("Sam's PetStore");
        System.out.println("**** Welcome to " + ps.getStoreName() + "****");
    
        while (true) {
            // Displays main menu
            System.out.println("Please select from one of the following menu otions");
            System.out.println("\t1. Buy a new pet");
            System.out.println("\t2. Register a new member");
            System.out.println("\t3. Start adoption drive (add new pets)");
            System.out.println("\t4. Check current inventory");
            System.out.println("\t5. Register new pet to Owner profile");
            System.out.println("\t6. Exit");
            System.out.println("\t7. Compare products");
            System.out.println("\t8. Display inventory total price");
    
            int choice1 = scnr.nextInt();
            scnr.nextLine(); // Handles the newline character after reading an integer
            
            // Switch statement to handle the user's choice
            switch (choice1) {
                // Buys new pet 
                case 1:
                ArrayList<Pet> pets = ps.getInventory();
                if (pets.isEmpty()) {
                    System.out.println("No pets available.");
                } else {
                    for (int i = 0; i < pets.size(); i++) {
                        Pet pet = pets.get(i);
                        System.out.printf("%d. Name: %s, Price: %.2f, Breed: %s\n", i + 1, pet.getName(), pet.getPrice(), pet.getBreed());
                    }

                    System.out.println("Enter the number of the pet you want to buy:");
                    int petIndex = scnr.nextInt() - 1;
                    if (petIndex >= 0 && petIndex < pets.size()) {
                        Pet selectedPet = pets.get(petIndex);
                        System.out.printf("You have bought %s, a %s for %.2f.\n", selectedPet.getName(), selectedPet.getBreed(), selectedPet.getPrice());
                        // Removes  pet from the inventory 
                        if (selectedPet instanceof Dog) {
                            ps.getAvailableDogs().remove((Dog) selectedPet);
                        } else if (selectedPet instanceof Cat) {
                            ps.getAvailableCats().remove((Cat) selectedPet);
                        } else if (selectedPet instanceof ExoticPet) {
                            ps.getAvailableExoticPets().remove((ExoticPet) selectedPet);
                        }
                        double petPrice = selectedPet.getPrice();
                        ps.updateTotalAmountSpent(petPrice);
                    } else {
                        System.out.println("Invalid pet number. Please try again.");
                    }
                }
                break;
                // Registers new member
                case 2:
                    int newID = ps.generateUniqueMemberID();
                    System.out.println("Enter member details! \nName: ");
                    String mName = scnr.next();
                    System.out.println("Do you want to become a premium member? ($10 Charge) (Yes/No):\n ");
                    String isPremium = scnr.next();
                    if (isPremium.toLowerCase() == "no" ){
                        Member newMember = new Member(mName, newID , true);
                        System.out.println("Your unique ID is: " + newID);
                        ArrayList<Member> currentMemberList = ps.getMemberList();
                        currentMemberList.add(newMember);
                        ps.setMemberList(currentMemberList);
                    } else{PremiumMember newMember = new PremiumMember(mName, newID, false, false);
                        System.out.println("Your unique ID is: " + newID);
                        ArrayList<Member> currentMemberList = ps.getMemberList();
                        currentMemberList.add(newMember);
                        ps.setMemberList(currentMemberList);}
                    break;
                // Adoption Drive
                case 3:
                    ps.startAdoptionDrive();
                    break;
                // Displays purchase
                case 4:
                    ps.displayInventory();
                    break;
                // Exit
                case 6:
                System.out.println("Thank you for visiting our pet store!");
                System.out.printf("Total amount spent: $%.2f%n", ps.getTotalAmountSpent());
                System.out.println("Goodbye!");
                System.exit(1);
                // Compare
                case 7:
                    compareProducts(ps);
                    break;
                // Displays the total price
                case 8:
                    displayInventoryTotal(ps);
                    break;

                default:
                    System.out.println("Invalid choice, try again.");
            }
        }}}