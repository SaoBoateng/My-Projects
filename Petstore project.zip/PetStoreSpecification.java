import java.util.*;
public interface PetStoreSpecification {
    void adoptionDrive(ArrayList<Object> pets);
    double inventoryValue();
}