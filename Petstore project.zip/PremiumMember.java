
public class PremiumMember extends Member {
    
    private boolean duesPaid;
    // Creates a new PremiumMember object
    public PremiumMember(String name, int memberID, boolean newsletterSubscribed, boolean duesPaid) {
        super(name, memberID, newsletterSubscribed);
        this.duesPaid = duesPaid;
    }
    // Returns whether the premium member has paid their dues or not

    public boolean isDuesPaid() {
        return duesPaid;
    }
    // Sets whether the premium member has paid their dues or not

    public void setDuesPaid(boolean duesPaid) {
        this.duesPaid = duesPaid;
    }
    
}
