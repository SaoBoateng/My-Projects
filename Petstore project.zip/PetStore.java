
import java.util.*;

public class PetStore implements PetStoreSpecification{

    private String storeName;
    // ArrayLists
    private ArrayList<Dog> availableDogs = new ArrayList();
    private ArrayList<Cat> availableCats = new ArrayList();
    private ArrayList<ExoticPet> availableExoticPets = new ArrayList();
    private ArrayList<Pet> availablePets = new ArrayList<>();
    private ArrayList<Member> memberList = new ArrayList();

    private double totalAmountSpent = 0;

    public ArrayList<Member> allMembers() {
        ArrayList<Member> lists = new ArrayList<>();
        lists.addAll(memberList);
        lists.addAll(premiumMemberList);
        return lists;
    }

    private ArrayList<PremiumMember> premiumMemberList = new ArrayList();
    private static int nextPetID = 1;
    public ArrayList<Pet> getInventory() {
        ArrayList<Pet> inventory = new ArrayList<>();
        inventory.addAll(availableDogs);
        inventory.addAll(availableCats);
        inventory.addAll(availableExoticPets);
        return inventory;
    }
    public void updateTotalAmountSpent(double amount) {
        this.totalAmountSpent += amount;
    }
    
    public double getTotalAmountSpent() {
        return totalAmountSpent;
    }

    public PetStore(String storeName) {
        this.storeName = storeName;
        // Default pets and people
        Dog dog1 = new Dog("Ollson", "Pitbull", "Female", 12, 85, getNextPetID(), 500);
        Dog dog2 = new Dog("Daren", "German Shepard", "Male", 3, 35, getNextPetID(), 450);
        Cat cat1 = new Cat("Ben", "Golden Retriever", "Female", 6, 15,getNextPetID(), 200);
        Cat cat2 = new Cat("Sam", "Bulldog", "Male",6, 18, getNextPetID(), 150);
        ExoticPet ep1  = new ExoticPet("Waafle", "Wallaby", "Male", 6, 0.8, getNextPetID(), 75);
        ExoticPet ep2 = new ExoticPet("Mali", "Hedgehog", "Male", 4, 2, getNextPetID(), 95);
        availableDogs.add(dog1);
        availableDogs.add(dog2);
        availableCats.add(cat1);
        availableCats.add(cat2);
        availableExoticPets.add(ep1);
        availableExoticPets.add(ep2);
        Member member1 = new Member("Jo", 234, true);
        member1.addCat(new Cat("Baljeet", "Pussy Cat", "Male",1,10,0,0));
        PremiumMember member2 = new PremiumMember("Levine", 567, true, true);
        member2.addExoticPet(new ExoticPet("JohnB", "Artic Monkey", "Male", 5, 1, 0,0));
    }
    // Finding a pet using it's ID
    public Pet findPetById(int id) {
        for (Pet pet : availablePets) {
            if (pet.getPetID() == id) {
                return pet;
            }
        }
        return null;
    }
    // Adding a pet to the list.
    public void addPet(Pet pets) {
        availablePets.add(pets);
    }
    // The function adds pets to the list of available pets.
    @Override
    public void adoptionDrive(ArrayList<Object> pets) {
        for (Object pet : pets) {
            if (pet instanceof Dog) {
                availableDogs.add((Dog) pet);
            } else if (pet instanceof Cat) {
                availableCats.add((Cat) pet);
            } else if (pet instanceof ExoticPet) {
                availableExoticPets.add((ExoticPet) pet);
            }
        }
    }
    // Function verifies if you're a member
    public boolean isMember(int memberID) {
        for (Member member : allMembers()) {
            if (member.getMemberID() == memberID) {
                return true;
            }
        }
        return false;
    }
    // Adoption drive
    public void startAdoptionDrive() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("How many pets do you want to add to the adoption drive?");
        int numberOfPets = scanner.nextInt();
        // To help catagorize.
        for (int i = 0; i < numberOfPets; i++) {
            System.out.println("Enter the type of pet (Dog, Cat, ExoticPet):");
            String petType = scanner.next();
            System.out.println("Enter the name of the pet:");
            String name = scanner.next();
            System.out.println("Enter the breed of the pet:");
            String breed = scanner.next();
            System.out.println("Enter the gender of the pet:");
            String gender = scanner.next();
            System.out.println("Enter the age of the pet:");
            int age = scanner.nextInt();
            System.out.println("Enter the weight of the pet:");
            double weight = scanner.nextDouble();
            System.out.println("Enter the price of the pet:");
            double price = scanner.nextDouble();
            // Pet stuff
            Pet newPet = null;
            int petID = getNextPetID();
            switch (petType.toLowerCase()) {
                case "dog":
                    newPet = new Dog(name, breed, gender, age, weight, petID, price);
                    availableDogs.add((Dog) newPet);
                    break;
                case "cat":
                    newPet = new Cat(name, breed, gender, age, weight, petID, price);
                    availableCats.add((Cat) newPet);
                    break;
                case "exoticpet":
                    newPet = new ExoticPet(name, breed, gender, age, weight, petID, price);
                    availableExoticPets.add((ExoticPet) newPet);
                    break;
                default:
                    System.out.println("Invalid pet type. Skipping this pet.");
                    break;
            }
    
            if (newPet != null) {
                availablePets.add(newPet);
                System.out.println("Pet added successfully!");
            }
        }
    }
    

    public void displayInventory() {
        // Display the list of available pets in the store
        System.out.println("Available Pets:");
        for (Pet pet : getInventory()) {
            System.out.println("Pet ID: " + pet.getPetID() + ", Name: " + pet.getName() + ", Breed: " + pet.getBreed() + ", Price: $" + pet.getPrice());
        }
    }
    // Creates a new member ID each time
    public int generateUniqueMemberID() {
        int highestID = 1;
        for (Member member : allMembers()) {
            if (member.getMemberID() > highestID) {
                highestID = member.getMemberID();
            }
        }
        return highestID + 1;
    }
    // Setters and Getters
    public static int getNextPetID() {
        nextPetID++;
        return nextPetID-1;
    }
    

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public ArrayList<Dog> getAvailableDogs() {
        return availableDogs;
    }

    public void setAvailableDogs(ArrayList<Dog> availableDogs) {
        this.availableDogs = availableDogs;
    }

    public ArrayList<Cat> getAvailableCats() {
        return availableCats;
    }

    public void setAvailableCats(ArrayList<Cat> availableCats) {
        this.availableCats = availableCats;
    }

    public ArrayList<ExoticPet> getAvailableExoticPets() {
        return availableExoticPets;
    }

    public void setAvailableExoticPets(ArrayList<ExoticPet> availableExoticPets) {
        this.availableExoticPets = availableExoticPets;
    }

    public ArrayList<Member> getMemberList() {
        return memberList;
    }

    public void setMemberList(ArrayList<Member> memberList) {
        this.memberList = memberList;
    }

    public ArrayList<PremiumMember> getPremiumMemberList() {
        return premiumMemberList;
    }

    public void setPremiumMemberList(ArrayList<PremiumMember> premiumMemberList) {
        this.premiumMemberList = premiumMemberList;
    }
    
@Override
    public double inventoryValue() {
        // Calculate and return the total inventory value
        double totalValue = 0;

        for (Dog dog : availableDogs) {
            totalValue += dog.getPrice();
        }

        for (Cat cat : availableCats) {
            totalValue += cat.getPrice();
        }

        for (ExoticPet exoticPet : availableExoticPets) {
            totalValue += exoticPet.getPrice();
        }

        return totalValue;
    }
}