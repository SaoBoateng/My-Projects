public class Cat extends Pet {
    public Cat(String name, String breed, String gender, int age, double weight, int petID, double price) {
        super(name, breed, gender, age, weight, petID, price);
    }
}