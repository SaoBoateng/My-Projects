
import java.util.ArrayList;

public class Member {
    
    // instance variables to store member information
    private String name;
    private int memberID;
    private boolean newsletterSubscribed;
    private ArrayList<Dog> dogsOwned = new ArrayList();
    private ArrayList<Cat> catsOwned = new ArrayList();
    private ArrayList<ExoticPet> exoticPetsOwned = new ArrayList();
    private double amountSpent = 0;

    // constructor to create a new Member object with given information
    public Member(String name, int memberID, boolean newsletterSubscribed) {
        this.name = name;
        this.memberID = memberID;
        this.newsletterSubscribed = newsletterSubscribed;
    }

    // accessor method for name instance variable
    public String getName() {
        return name;
    }

    // accessor method for memberID instance variable
    public int getMemberID() {
        return memberID;
    }

    // accessor method for newsletterSubscribed instance variable
    public boolean isNewsletterSubscribed() {
        return newsletterSubscribed;
    }

    // accessor method for dogsOwned instance variable
    public ArrayList<Dog> getDogsOwned() {
        return dogsOwned;
    }

    // accessor method for catsOwned instance variable
    public ArrayList<Cat> getCatsOwned() {
        return catsOwned;
    }

    // accessor method for exoticPetsOwned instance variable
    public ArrayList<ExoticPet> getExoticPetsOwned() {
        return exoticPetsOwned;
    }

    // accessor method for amountSpent instance variable
    public double getAmountSpent() {
        return amountSpent;
    }

    // mutator method for name instance variable
    public void setName(String name) {
        this.name = name;
    }

    // mutator method for memberID instance variable
    public void setMemberID(int memberID) {
        this.memberID = memberID;
    }

    // mutator method for newsletterSubscribed instance variable
    public void setNewsletterSubscribed(boolean newsletterSubscribed) {
        this.newsletterSubscribed = newsletterSubscribed;
    }

    // mutator method for amountSpent instance variable
    public void setAmountSpent(double amountSpent) {
        this.amountSpent = amountSpent;
    }
     
    // method to add a Dog object to the dogsOwned list
     public void addDog(Dog dog) {
         dogsOwned.add(dog);
     }

     // method to add a Cat object to the catsOwned list
     public void addCat(Cat cat) {
         catsOwned.add(cat);
     }

     // method to add an ExoticPet object to the exoticPetsOwned list
     public void addExoticPet(ExoticPet exoticPet) {
         exoticPetsOwned.add(exoticPet);
     }
}
