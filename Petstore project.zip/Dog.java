public class Dog extends Pet {
    public Dog(String name, String breed, String gender, int age, double weight, int petID, double price) {
        super(name, breed, gender, age, weight, petID, price);
    }
}