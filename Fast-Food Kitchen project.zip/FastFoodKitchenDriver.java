import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.InputMismatchException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.io.IOException;

public class FastFoodKitchenDriver {

    /**
     *  command line arguments
     */
    public static void main(String[] args)throws FileNotFoundException, IOException {

        FastFoodKitchen kitchen = new FastFoodKitchen();
        ArrayList<BurgerOrder> listNumOrders = kitchen.getOrderList();
        Scanner fileScanner = null;

        try {
            fileScanner = new Scanner(new File("burgerOrders.txt"));
        } catch (FileNotFoundException ex) {
            System.out.println("burgerOrders.txt not found");
        }

        Scanner sc = new Scanner(System. in);

        while (kitchen.getNumOrdersPending() != 0) {

            try {
                // User option list
                System.out.println(
                    "Please select from the following menu of options, by typing a number:"
                );
                System.out.println("\t 1. Order food");
                System.out.println("\t 2. Cancel last order");
                System.out.println("\t 3. Show number of orders currently pending");
                System.out.println("\t 4. Complete order");
                System.out.println("\t 5. Check on order");
                System.out.println("\t 6. Cancel order");
                System.out.println("\t 7. Exit");

                int num = sc.nextInt();
                switch (num) {
                    case 1:
                        System.out.println("How many hamburgers do you want?");
                        int ham = sc.nextInt();
                        System.out.println("How many cheeseburgers do you want?");
                        int cheese = sc.nextInt();
                        System.out.println("How many veggieburgers do you want?");
                        int veggie = sc.nextInt();
                        System.out.println("How many sodas do you want?");
                        int sodas = sc.nextInt();
                        System.out.println("Is your order to go? (Y/N)");
                        char letter = sc.next().charAt(0);
                        boolean TOGO = false;
                        if (letter == 'Y' || letter == 'y') {
                            TOGO = true;
                        }
                        int orderNum = kitchen.addOrder(ham, cheese, veggie, sodas, TOGO);
                        System.out.println("Thank you. Your order number is " + orderNum);
                        System.out.println();
                        break;
                    case 2:
                        boolean ready = kitchen.cancelLastOrder();
                        if (ready) {
                            System.out.println("Thank you. The last order has been canceled");
                        } else {
                            System.out.println("Sorry. There are no orders to cancel.");
                        }
                        System.out.println();
                        break;
                    case 3:
                        System.out.println(
                            "There are " + kitchen.getNumOrdersPending() + " pending orders"
                        );
                        break;
                    case 4:
                        System.out.println("Enter order number to complete?");
                        int order = sc.nextInt();
                        kitchen.completeSpecificOrder(order);
                        System.out.println("Your order is ready. Thank you!");
                        break;
                    case 5:
                        System.out.println("What is your order number?");
                        order = sc.nextInt();
                        ready = kitchen.isOrderDone(order);
                        if (ready) {
                            System.out.println("Sorry, no order with this number was found.");
                        } else {
                            System.out.println(
                                "No, it's not ready, but it should be up soon. Sorry for the wait."
                            );
                        }
                        System.out.println();
                        break;
                    case 6:
                        System.out.println("What is your order number?");
                        order = sc.nextInt();
                        boolean cancel = kitchen.cancelOrder(order);
                        if (cancel) {
                            System.out.println("Your order has been successfully cancelled ");
                        } else {
                            System.out.println("Sorry, we can’t find your order number in the system");
                        }
                        System.out.println();
                        break;
                    case 7:
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Sorry, but you need to enter a 1, 2, 3, 4, 5, 6, or a 7");

                }

            } catch (InputMismatchException ex) {
                System.out.println("The value you have entered is incorrect. Please try again");
            } catch (Exception ex) {
                System.out.println(
                    "General Exception caught due to incorrect input. Please try again"
                );
            }
            String line;
            fileScanner.nextLine();
            while (fileScanner.hasNext()) {
                line = fileScanner.nextLine();
                String[] stringArray = line.split(",");
                BurgerOrder order1 = new BurgerOrder(
                    Integer.parseInt(stringArray[1]),
                    Integer.parseInt(stringArray[2]),
                    Integer.parseInt(stringArray[3]),
                    Integer.parseInt(stringArray[4]),
                    Boolean.parseBoolean(stringArray[5]),
                    Integer.parseInt(stringArray[0])
                );
                listNumOrders.add(order1);
                kitchen.addOrder(
                    Integer.parseInt(stringArray[1]),
                    Integer.parseInt(stringArray[2]),
                    Integer.parseInt(stringArray[3]),
                    Integer.parseInt(stringArray[4]),
                    Boolean.parseBoolean(stringArray[5]),
                    Integer.parseInt(stringArray[0])
                );
            }
            try(FileOutputStream fs = new FileOutputStream("endOfDayReport.txt");
            PrintWriter outFS = new PrintWriter(fs)) {
                outFS.println("Orders of the Day: ");
                outFS.println(listNumOrders);
                for (int i = 0; i < listNumOrders.size(); i++) {
                    if (listNumOrders.get(i)instanceof BurgerOrder) {
                        if (listNumOrders.get(i).getOrderNum() >= 1) {
                            outFS.println("Completed: " + i);
                        }
                    }
                }
                FileOutputStream fm = new FileOutputStream("burgerOrders2.txt");
                PrintWriter outFM = new PrintWriter(fm);
                for (int i = 0; i < listNumOrders.size(); i++) {
                    if (listNumOrders.get(i).getOrderNum() >= 1) {
                        outFM.println("Remaining Order: ");
                        outFM.println(i);
                    }
                }
                outFM.close();
                fm.close();
            } catch (IOException ex) {
                System.out.println("Input Output Exception has been caught. Please try again.");
            }
        }
    }
}
